var container_gameplan = '#hsp_gameplan_widget';

var sport_id = '1';
var sport_tag = 'fussball';
var competition_id = '12';
var competition_tag = 'bundesliga';