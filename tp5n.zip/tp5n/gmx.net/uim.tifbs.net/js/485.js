/* Copyright 2008 United Internet AG */ 
var url = window.location.hostname;
if (0){}
else{
     void('<script type="text/javascript" src="//uim.tifbs.net/js/global_485_67.js"><\/script>');
}
/* V3.9 */
